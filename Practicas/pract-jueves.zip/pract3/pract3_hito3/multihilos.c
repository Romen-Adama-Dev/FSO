// File: multihilos.c
// Created: 09-06-2023 12:00:00
// Author: Romen Adama Caetano Ramirez
// Programa que reserva y libera asientos de forma concurrente

// Librerias de C 
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <stdint.h>
#include "sala.h"
#include "retardo.h"

// Variables globales definidas
#define NUM_ASIENTOS 30
#define MAX_RESERVAS 3

// Variables globales declaradas
int asientos[NUM_ASIENTOS] = {0};

// Variable mutex y condiciones
pthread_mutex_t mutex;
pthread_cond_t cond_reserva, cond_libera;

void *reserva_asientos(void *vargp) {
    int id = *(int *)vargp;

    for (int i = 0; i < MAX_RESERVAS; i++) {
        pthread_mutex_lock(&mutex);
        while (asientos_libres() == 0) {
            pthread_cond_wait(&cond_reserva, &mutex);
        }

        int asiento = reserva_asiento(id);
        pthread_mutex_unlock(&mutex);

        if (asiento != -1) {
            printf("Hilo %d reservó el asiento %d\n", id, asiento);
            pausa_aleatoria(3.0);
        } else {
            printf("Hilo %d no pudo reservar un asiento\n", id);
        }
    }

    return NULL;
}

void *libera_asientos(void *vargp) {
    int id = *(int *)vargp;

    for (int i = 0; i < MAX_RESERVAS; i++) {
        pthread_mutex_lock(&mutex);
        while (asientos_ocupados() == 0) {
            pthread_cond_wait(&cond_libera, &mutex);
        }

        int asiento = libera_asiento(id);
        pthread_mutex_unlock(&mutex);

        if (asiento != -1) {
            printf("Hilo %d liberó el asiento %d\n", id, asiento);
            pausa_aleatoria(3.0);
        } else {
            printf("Hilo %d no pudo liberar un asiento\n", id);
        }
    }

    return NULL;
}

void *muestra_estado_sala(void *vargp) {
    while (1) {
        pthread_mutex_lock(&mutex);
        printf("Estado de la sala: \n");
        for (int i = 1; i <= NUM_ASIENTOS; i++) {
            printf("%d ", estado_asiento(i));
        }
        printf("\n");
        pthread_mutex_unlock(&mutex);

        pausa_aleatoria(3.0);
    }

    return NULL;
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Uso: multihilos n m\n");
        return 1;
    }
    int n = atoi(argv[1]);
    int m = atoi(argv[2]);

    srand(time(NULL)); // Establecer la semilla aleatoria

    pthread_t threads_reserva[n];
    pthread_t threads_libera[m];
    crea_sala(NUM_ASIENTOS);
    pthread_mutex_init(&mutex, NULL);
    pthread_cond_init(&cond_reserva, NULL);
    pthread_cond_init(&cond_libera, NULL);

    pthread_t thread_estado_sala;
    pthread_create(&thread_estado_sala, NULL, muestra_estado_sala, NULL);

    // Lanzamiento de hilos de reserva
    for (int i = 0; i < n; i++) {
        int *id = malloc(sizeof(int));
        *id = i + 1;
        pthread_create(&threads_reserva[i], NULL, reserva_asientos, id);
    }

    // Lanzamiento de hilos de liberación
    for (int i = 0; i < m; i++) {
        int *id = malloc(sizeof(int));
        *id = i + 1;
        pthread_create(&threads_libera[i], NULL, libera_asientos, id);
    }

    // Espera a que todos los hilos de reserva terminen
    for (int i = 0; i < n; i++) {
        pthread_join(threads_reserva[i], NULL);
    }

    // Espera a que todos los hilos de liberación terminen
    for (int i = 0; i < m; i++) {
        pthread_join(threads_libera[i], NULL);
    }

    pthread_cancel(thread_estado_sala);
    pthread_mutex_destroy(&mutex);
    pthread_cond_destroy(&cond_reserva);
    pthread_cond_destroy(&cond_libera);
    elimina_sala();

    return 0;
}