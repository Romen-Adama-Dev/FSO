#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <stdint.h>
#include "sala.h"
#include "retardo.h"

#define NUM_ASIENTOS 10
#define MAX_RESERVAS 3

int asientos[NUM_ASIENTOS] = {0};

void *reserva_y_libera(void *vargp){
    int id = (intptr_t)vargp;
    int asientos_reservados[MAX_RESERVAS];
    
    for (int i = 0; i < MAX_RESERVAS; i++){
        if(asientos_libres() == 0){
            printf("Hilo %d: Error, no hay espacio en la sala\n", id);
            pthread_exit(NULL);
        }

        int asiento = reserva_asiento(id);
        if (asiento != -1){
            printf("Hilo %d reservó el asiento %d\n", id, asiento);
            asientos_reservados[i] = asiento;
        } else {
            printf("Hilo %d no pudo reservar un asiento\n", id);
        }
        pausa_aleatoria(5.0);
    }

    for (int i = 0; i < MAX_RESERVAS; i++){
        if(asientos_ocupados() == 0){
            printf("Hilo %d: Error, no hay asientos en la sala \n", id);
            pthread_exit(NULL);
        }

        int resultado = libera_asiento(asientos_reservados[i]);
        
        if (resultado == -1){
            printf("Hilo %d: Error, no se pudo liberar el asiento \n", id);
        } else if (resultado != id) {
            printf("Hilo %d: Error, liberó un asiento que no reservó \n", id);
        } else {
            printf("Hilo %d liberó el asiento \n", id);
        }
        pausa_aleatoria(5.0);
    }
    
    return NULL;
}

void *muestra_estado_sala(void *vargp){
    while (1){
        printf("Estado de la sala: \n");
        for (int i = 1; i < NUM_ASIENTOS; i++){
            printf("%d ", estado_asiento(i));
        }
        printf("\n");
        pausa_aleatoria(5.0);
    }
    return NULL;
}

int main(int argc, char *argv[]){
    srand(getpid());
    if(argc != 2){
        printf("Uso: multihilos n\n");
        return 1;
    }

    int n = atoi(argv[1]);
    pthread_t threads[n];

    crea_sala(NUM_ASIENTOS); 

    pthread_t thread_estado_sala;
    pthread_create(&thread_estado_sala, NULL, muestra_estado_sala, NULL);

    for(int i = 0; i < n; i++){
        pthread_create(&threads[i], NULL, reserva_y_libera, (void *)(intptr_t)i);
    }
    for(int i = 0; i < n; i++){
        pthread_join(threads[i], NULL);
    }

    pthread_cancel(thread_estado_sala);
    elimina_sala();

    return 0;
}
