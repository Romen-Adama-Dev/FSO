// File: retardo.h
// Utilidad para generar pausas aleatorias
// Se pueden utilizar en las prácticas de programación concurrente

// Genera una pausa aleatoria entre 0 y max_segundos
void pausa_aleatoria (float max_segundos);