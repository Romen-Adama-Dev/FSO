// File: sala.c
// Created: 31-03-2023 11:00:00
// Author: Romen Adama Caetano Ramirez

// Practica 1 Librerias
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "sala.h"

// Practica 2 Librerias
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>

// Practica 3 Librerias
// Incluir la biblioteca de hilos
#include <pthread.h>
#include <stdbool.h>

typedef enum {
    NO_ERROR = 0,
    ERROR = -1,
    ASIENTO_SIN_RESERVAR = 0,
    ERR_CAPACIDAD_INVALIDA = -1,
    ERR_ID_CLIENTE_YA_EXISTE = -1,
    ERR_SIN_ASIENTOS_LIBRES = -1,
    ERR_ASIENTO_OCUPADO = -1,
    ERR_ASIENTO_NO_VALIDO = -1,
    ERR_MEMORIA_ASIGNADA = -1,
    ERR_ASIENTO_YA_LIBRE = -1,
    ERR_SALA_NO_EXISTE = -1,
    ERR_ABRIR_ARCHIVO = -1,
    ERR_ESCRIBRIR_ARCHIVO = -1,
    ERR_SALA_NO_CREADA = -1,
    ERR_LEER_ARCHIVO = -1,
    ERR_NUM_ASIENTOS = -1,
    ERR_CARRAR_ARCHIVO = -1,
} sala_error;

typedef struct {
    int *asientos; // Puntero al array de asientos
    int capacidad; // Capacidad de la sala
    int libres; // Número de asientos libres
    int ocupados; // Número de asientos ocupados
    pthread_mutex_t mutex; // Mutex para sincronizar el acceso a la sala
    pthread_cond_t cond_reserva; // Variable de condición para reserva de asientos
    pthread_cond_t cond_libera; // Variable de condición para liberación de asientos
} Sala;

static Sala *sala = NULL; // Puntero a la sala global

void crea_sala(int capacidad) {
    // Comprobar si ya existe una sala creada
    if (sala != NULL) {
        // Liberar la memoria de la sala anterior
        elimina_sala();
    }

    // Comprobar que la capacidad de la sala sea válida
    if (capacidad <= 0) {
        // La capacidad de la sala no es válida, salir con un código de error
        exit(ERR_CAPACIDAD_INVALIDA);
    }

    // Asignar memoria para la estructura de la sala
    sala = (Sala*)malloc(sizeof(Sala));
    if (sala == NULL) {
        // No se pudo asignar memoria, salir con un código de error
        exit(ERR_MEMORIA_ASIGNADA);
    }

    // Asignar memoria para el array de asientos
    sala->asientos = (int*)malloc(capacidad * sizeof(int));
    if (sala->asientos == NULL) {
        // No se pudo asignar memoria, liberar la memoria de la sala y salir con un código de error
        free(sala);
        exit(ERR_MEMORIA_ASIGNADA);
    }

    // Inicializar la capacidad, número de asientos libres y ocupados
    sala->capacidad = capacidad;
    sala->libres = capacidad;
    sala->ocupados = 0;

    // Inicializar todos los asientos como libres
    for (int i = 0; i < capacidad; i++) {
        sala->asientos[i] = 0;
    }

    // Inicializar el mutex de la sala
    if (pthread_mutex_init(&(sala->mutex), NULL) != 0) {
        // Error al inicializar el mutex, liberar la memoria de la sala y salir con un código de error
        free(sala->asientos);
        free(sala);
        exit(ERR_MEMORIA_ASIGNADA);
    }

    // Inicializar las variables de condición de la sala
    if (pthread_cond_init(&(sala->cond_reserva), NULL) != 0 || pthread_cond_init(&(sala->cond_libera), NULL) != 0) {
        // Error al inicializar las variables de condición, liberar la memoria de la sala y salir con un código de error
        pthread_mutex_destroy(&(sala->mutex));
        free(sala->asientos);
        free(sala);
        exit(ERR_MEMORIA_ASIGNADA);
    }
}

void elimina_sala() {
    if (sala != NULL) {
    pthread_mutex_lock(&(sala->mutex));
    pthread_mutex_unlock(&(sala->mutex));
    pthread_mutex_destroy(&(sala->mutex));
    pthread_cond_destroy(&(sala->cond_reserva));
    pthread_cond_destroy(&(sala->cond_libera));
    free(sala->asientos);
    free(sala);
    sala = NULL;
    }

}

int reserva_asiento(int id) {
    const int ASIENTO_SIN_RESERVAR = 0;
    int asiento_reservado = ERR_SIN_ASIENTOS_LIBRES; // Variable para mantener el asiento reservado

    pthread_mutex_lock(&(sala->mutex));

    if (sala == NULL) {
        pthread_mutex_unlock(&(sala->mutex));
        return ERR_SALA_NO_CREADA;
    }

    if (sala->libres == 0) {
        pthread_cond_wait(&(sala->cond_reserva), &(sala->mutex));
    }

    for (int i = 0; i < sala->capacidad; i++) {
        if (sala->asientos[i] == ASIENTO_SIN_RESERVAR) {
            sala->asientos[i] = id;
            sala->libres--;
            sala->ocupados++;
            asiento_reservado = i + 1;
            break;
        }
    }

    pthread_cond_signal(&(sala->cond_libera));
    pthread_mutex_unlock(&(sala->mutex));
    return asiento_reservado;

}

int libera_asiento(int asiento) {
    int id;

    pthread_mutex_lock(&(sala->mutex));

    if (sala == NULL) {
        pthread_mutex_unlock(&(sala->mutex));
        return ERR_SALA_NO_EXISTE;
    }

    if (asiento < 1 || asiento > sala->capacidad) {
        pthread_mutex_unlock(&(sala->mutex));
        return ERR_ASIENTO_NO_VALIDO;
    }

    if (sala->asientos[asiento - 1] == 0) {
        pthread_mutex_unlock(&(sala->mutex));
        return ERR_ASIENTO_YA_LIBRE;
    }

    if (sala->ocupados == 0) {
        pthread_cond_wait(&(sala->cond_libera), &(sala->mutex));
    }

    id = sala->asientos[asiento - 1];
    sala->asientos[asiento - 1] = 0;
    sala->libres++;
    sala->ocupados--;

    pthread_cond_signal(&(sala->cond_reserva));
    pthread_mutex_unlock(&(sala->mutex));
    return id;
}

int estado_asiento(int asiento) {
    int estado;

    pthread_mutex_lock(&(sala->mutex));

    if (asiento < 1 || asiento > sala->capacidad) {
        pthread_mutex_unlock(&(sala->mutex));
        return ERR_ASIENTO_NO_VALIDO;
    }

    estado = (sala->asientos[asiento - 1] == 0) ? NO_ERROR : sala->asientos[asiento - 1];

    pthread_mutex_unlock(&(sala->mutex));
    return estado;
}

int asientos_libres() {
    int libres;

    pthread_mutex_lock(&(sala->mutex));

    if (sala == NULL) {
        pthread_mutex_unlock(&(sala->mutex));
        return NO_ERROR;
    }

    libres = sala->libres;

    pthread_mutex_unlock(&(sala->mutex));
    return libres;
}

int asientos_ocupados() {
    int ocupados;

    pthread_mutex_lock(&(sala->mutex));

    if (sala == NULL) {
        pthread_mutex_unlock(&(sala->mutex));
        return NO_ERROR;
    }

    ocupados = sala->ocupados;

    pthread_mutex_unlock(&(sala->mutex));
    return ocupados;
}

int capacidad() {
    int capacidad;

    pthread_mutex_lock(&(sala->mutex));

    if (sala == NULL) {
        pthread_mutex_unlock(&(sala->mutex));
        return NO_ERROR;
    }
    capacidad = sala->capacidad;

    pthread_mutex_unlock(&(sala->mutex));
    return capacidad;
}
