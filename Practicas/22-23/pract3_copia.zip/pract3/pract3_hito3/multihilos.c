#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <stdint.h>
#include "sala.h"
#include "retardo.h"

#define MAX_RESERVAS 3

typedef struct {
    int *asientos_reservados;
    int num_reservas;
} ReservasHilo;

int *asientos = NULL;
ReservasHilo *reservas_hilos = NULL;

void *reserva_y_libera(void *vargp){
    intptr_t id = (intptr_t)vargp;
    ReservasHilo *reservas = &reservas_hilos[id];

    for (int i = 0; i < MAX_RESERVAS; i++) {
        int asiento = reserva_asiento(id + 1);
        if (asiento != -1){
            printf("Hilo %ld reservó el asiento %d\n", id, asiento);
            reservas->asientos_reservados[i] = asiento;
            reservas->num_reservas++;
        } else {
            printf("Hilo %ld no pudo reservar un asiento\n", id);
        }
        pausa_aleatoria(1.0);
    }

    for (int i = 0; i < reservas->num_reservas; i++) {
        int asiento = reservas->asientos_reservados[i];
        if (estado_asiento(asiento) != 0) {
            if (libera_asiento(asiento) != 0){
                printf("Hilo %ld liberó el asiento %d\n", id, asiento);
            } else {
                printf("Error: Hilo %ld intentó liberar un asiento no ocupado (%d)\n", id, asiento);
            }
        } else {
            printf("Error: Hilo %ld intentó liberar un asiento no ocupado (%d)\n", id, asiento);
        }
        pausa_aleatoria(1.0);
    }
    
    return NULL;
}

void *muestra_estado_sala(void *vargp){
    int num_asientos = *(int*)vargp;
    while (1){
        printf("Estado de la sala: \n");
        for (int i = 0; i < num_asientos; i++){
            printf("%d", estado_asiento(i + 1));
        }
        printf("\n");
        pausa_aleatoria(5.0);
    }
    return NULL;
}

int main(int argc, char *argv[]){
    if(argc != 3){
        printf("Uso: multihilos n m\n");
        return 1;
    }

    int n = atoi(argv[1]); // Número de hilos
    int m = atoi(argv[2]); // Número de asientos
    pthread_t threads[n];

    asientos = malloc(m * sizeof(int)); 
    reservas_hilos = malloc(n * sizeof(ReservasHilo)); 

    for(int i = 0; i < n; i++){
        reservas_hilos[i].asientos_reservados = malloc(MAX_RESERVAS * sizeof(int));
        reservas_hilos[i].num_reservas = 0;
    }

    crea_sala(m);

    pthread_t thread_estado_sala;
    pthread_create(&thread_estado_sala, NULL, muestra_estado_sala, &m);

    for(int i = 0; i < n; i++){
        pthread_create(&threads[i], NULL, reserva_y_libera, (void *)(intptr_t)i);
    }

    for(int i = 0; i < n; i++){
        pthread_join(threads[i], NULL);
    }

    pthread_cancel(thread_estado_sala);

    for(int i = 0; i < n; i++){
        free(reservas_hilos[i].asientos_reservados);
    }

    free(asientos);
    free(reservas_hilos);

    elimina_sala();

    return 0;
}
